
- State Template Source Version 6.3.0-beta.3
- You may use the CDN location instead of this folder 
- https://california.azureedge.net/cdt/statetemplate/6.3.0-beta.3/